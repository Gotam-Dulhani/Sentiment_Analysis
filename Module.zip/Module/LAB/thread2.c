#include <stdio.h>
#include <pthread.h>

int counter = 0;  // Shared resource

void *increment(void *param) {
    for (int i = 0; i < 100000; i++)
        counter++;  // Race condition
    pthread_exit(0);
}

int main() {
    pthread_t t1, t2;

    pthread_create(&t1, NULL, increment, NULL);
    pthread_create(&t2, NULL, increment, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    printf("Counter = %d\n", counter);  // Expected 200000 but may vary
    return 0;
}
