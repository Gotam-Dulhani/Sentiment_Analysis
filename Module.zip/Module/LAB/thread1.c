#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

int sum = 0;  // Shared resource

// Thread function
void *runner(void *param) {
    int upper = atoi(param); // Convert string argument to int
    for (int i = 1; i <= upper; i++)
        sum += i;  // Update shared variable
    pthread_exit(0);
}

int main(int argc, char *argv[]) {
    pthread_t tid;             // Thread ID
    pthread_attr_t attr;       // Thread attributes

    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return -1;
    }

    pthread_attr_init(&attr);  // Initialize attributes
    pthread_create(&tid, &attr, runner, argv[1]);  // Create thread
    pthread_join(tid, NULL);   // Wait for thread to finish

    printf("Sum = %d\n", sum); // Print result
    return 0;
}
