#include <stdlib.h>

int main() {
    system("mkdir testdir");
    system("cp input.txt testdir/");
    system("ls");
    system("rmdir testdir");
    return 0;
}
