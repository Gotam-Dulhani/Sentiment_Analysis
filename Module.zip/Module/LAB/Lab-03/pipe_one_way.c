#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(){
    char msg_child[20] = "Hello Parent";
    char buffer[20];

    int pipe1[2];
    pipe(pipe1);
    pid_t pid;

    pid = fork();

    if(pid == 0){
        printf("Child Writting... \t\n");
        close(pipe1[0]); //closed reading end for child
        write(pipe1[1], msg_child, 20);
    }

    else{
        close(pipe1[1]); //closing writting end for parent
        read(pipe1[0], buffer, 20);
        printf("Parent Process Reading..\n");
        printf("msg from child %s", buffer);
    }

    return 0;
}