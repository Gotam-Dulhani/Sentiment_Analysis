// client.c
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#define FIFO "myfifo"

int main()
{
    int fd;
    char buffer[100];

    // Open FIFO in read-write mode
    fd = open(FIFO, O_RDWR);

    //Send message to server
    char msg[] = "Hello from Client";
    write(fd, msg, strlen(msg)+1);

    //Read reply from server
    read(fd, buffer, sizeof(buffer));
    printf("Client received: %s\n", buffer);

    close(fd);
    return 0;
}s