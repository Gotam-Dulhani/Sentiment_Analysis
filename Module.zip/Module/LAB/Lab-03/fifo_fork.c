#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <sys/types.h>
#define FIFO "myfifo"

int main()
{
    int fd;
    pid_t pid;
    char buffer[100];

    // Create FIFO
    mkfifo(FIFO, 0666);

    pid = fork();

    if(pid > 0)
    {
        fd = open(FIFO, O_RDWR);
        //Parent writes
        char msg[] = "Hello from Parent";
        write(fd, msg, strlen(msg)+1);

        //Parent reads reply
        read(fd, buffer, sizeof(buffer));
        printf("Parent received: %s\n", buffer);

        close(fd);
    }
    else if(pid == 0)
    {
        fd = open(FIFO, O_RDWR);
        //Child reads
        read(fd, buffer, sizeof(buffer));
        printf("Child received: %s\n", buffer);

        //Child replies
        char reply[] = "Hello from Child";
        write(fd, reply, strlen(reply)+1);

        close(fd);
    }
    return 0;
}