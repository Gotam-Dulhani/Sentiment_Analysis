#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[]) {

    if(argc != 3) {
        printf("Usage: ./copy source destination\n");
        return 1;
    }

    int fd1 = open(argv[1], O_RDONLY);
    if(fd1 < 0) {
        perror("Error");
        return 1;
    }

    int fd2 = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0644);

    char buffer[1024];
    int bytes;

    while((bytes = read(fd1, buffer, sizeof(buffer))) > 0)
        write(fd2, buffer, bytes);

    close(fd1);
    close(fd2);
    return 0;
}
