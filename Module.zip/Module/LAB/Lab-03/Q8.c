#include <stdio.h>
#include <unistd.h>
#include <signal.h>

void handler(int sig) {
    printf("\nAlarm received. Exiting...\n");
    _exit(0);
}

int main() {
    signal(SIGALRM, handler);
    alarm(5);

    while(1) {
        printf("Running...\n");
        sleep(1);
    }

    return 0;
}
