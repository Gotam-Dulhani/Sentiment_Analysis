#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <signal.h>
#include <unistd.h>

#define NUM_THREADS 4

pthread_t threads[NUM_THREADS]; // Global array for thread IDs

// Signal handler
void sigusr1_handler(int signum) {
    int tid = gettid();     // thread id (Linux specific)
    int pid = getpid();     // process id
    int ppid = getppid();   // parent process id

    fprintf(stdout,
        "Thread %lu received SIGUSR1 (pid=%d, ppid=%d, tid=%d)\n",
        pthread_self(), pid, ppid, tid);
}

// Thread function
void *thread_function(void *arg) {
    // signal(SIGUSR1, sigusr1_handler); // optional (main already sets it)

    while (1) {
        sleep(1); // keep thread alive
    }
    return NULL;
}

int main() {
    // Register signal handler
    signal(SIGUSR1, sigusr1_handler);

    // Create threads
    for (int i = 0; i < NUM_THREADS; ++i) {
        if (pthread_create(&threads[i], NULL, thread_function, NULL) != 0) {
            perror("pthread_create");
            exit(EXIT_FAILURE);
        }
    }

    int pid = getpid();
    int ppid = getppid();

    printf("Process ID: %d, Parent ID: %d\n", pid, ppid);

    printf("Thread IDs: %lu, %lu, %lu, %lu\n",
           threads[0], threads[1], threads[2], threads[3]);

    // Send signal to process
    kill(pid, SIGUSR1);

    // Send signal to specific thread (3rd thread)
    pthread_kill(threads[2], SIGUSR1);

    // Wait for threads
    for (int i = 0; i < NUM_THREADS; ++i) {
        if (pthread_join(threads[i], NULL) != 0) {
            perror("pthread_join");
            exit(EXIT_FAILURE);
        }
    }

    return 0;
}
