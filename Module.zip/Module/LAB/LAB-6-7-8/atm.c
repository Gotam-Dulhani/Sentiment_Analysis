#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#define FIFO_NAME "atm_fifo"

int main() {
    int fd;
    char input[100];

    printf("Enter Account Number and PIN: ");
    fgets(input, sizeof(input), stdin);

    fd = open(FIFO_NAME, O_WRONLY);
    write(fd, input, strlen(input) + 1);
    close(fd);

    return 0;
}
