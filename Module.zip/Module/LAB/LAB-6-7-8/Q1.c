#include <stdio.h>
#include <pthread.h>
#include <time.h>

#define TOTAL 10000000
#define THREADS 5
long long counter = 0;

void *increment(void *arg){
    for(int i = 0; i < TOTAL/THREADS; i++){
        counter++; //race condition 
    }
    return NULL; }

double time_diff(struct timespec start, struct timespec end){
    return (end.tv_sec - start.tv_sec) +
           (end.tv_nsec - start.tv_nsec) / 1e9; }

int main(){
    struct timespec start, end;

    //SERIAL
    counter = 0;
    clock_gettime(CLOCK_MONOTONIC, &start);
    for (int i = 0; i < TOTAL; i++)
        counter++;

    clock_gettime(CLOCK_MONOTONIC, &end);

    double serial_time = time_diff(start, end);

    printf("Serial Counter = %lld\n", counter);
    printf("Serial Time = %f sec\n\n", serial_time);

    //MULTITHREADED
    counter = 0;
    pthread_t t[THREADS];

    clock_gettime(CLOCK_MONOTONIC, &start);
    for(int i = 0; i < THREADS; i++)
        pthread_create(&t[i], NULL, increment, NULL);

    for(int i = 0; i < THREADS; i++)
        pthread_join(t[i], NULL);

    clock_gettime(CLOCK_MONOTONIC, &end);

    double thread_time = time_diff(start, end);

    printf("Thread Counter = %lld\n", counter);
    printf("Thread Time = %f sec\n", thread_time);
    return 0; }
    
