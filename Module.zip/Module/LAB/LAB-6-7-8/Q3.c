#include <stdio.h>
#include <pthread.h>
#include <time.h>

#define SIZE 1000000
#define THREADS 4

int arr[SIZE];
int max_value = 0;

typedef struct {
    int start, end;
} Data;

void *find_max(void *arg) {
    Data *d = (Data *)arg;
    int local_max = arr[d->start];

    for(int i = d->start; i < d->end; i++){
        if (arr[i] > local_max)
            local_max = arr[i];
    }

    if(local_max > max_value)
        max_value = local_max;   //race condition

    return NULL;
}

double time_diff(struct timespec s, struct timespec e){
    return (e.tv_sec - s.tv_sec) + (e.tv_nsec - s.tv_nsec)/1e9;
}

int main(){
    struct timespec start, end;

    for (int i = 0; i < SIZE; i++)
        arr[i] = i % 1000;

    //SERIAL
    max_value = arr[0];

    clock_gettime(CLOCK_MONOTONIC, &start);

    for(int i = 0; i < SIZE; i++)
        if (arr[i] > max_value)
            max_value = arr[i];

    clock_gettime(CLOCK_MONOTONIC, &end);

    double serial_time = time_diff(start, end);

    printf("Serial Max = %d\n", max_value);
    printf("Serial Time = %f sec\n\n", serial_time);

    //MULTITHREAD
    pthread_t t[THREADS];
    Data d[THREADS];

    int chunk = SIZE / THREADS;

    clock_gettime(CLOCK_MONOTONIC, &start);

    for(int i = 0; i < THREADS; i++){
        d[i].start = i * chunk;
        d[i].end = (i == THREADS-1) ? SIZE : (i+1)*chunk;

        pthread_create(&t[i], NULL, find_max, &d[i]);
    }

    for(int i = 0; i < THREADS; i++)
        pthread_join(t[i], NULL);

    clock_gettime(CLOCK_MONOTONIC, &end);

    double thread_time = time_diff(start, end);

    printf("Thread Max = %d\n", max_value);
    printf("Thread Time = %f sec\n", thread_time);

    return 0;
}


