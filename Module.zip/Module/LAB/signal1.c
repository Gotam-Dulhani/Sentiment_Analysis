#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

void sigint_handler(int sig) {
    printf("\nSIGINT caught! (Ctrl+C pressed)\n");
    exit(0);
}

int main() {
    signal(SIGINT, sigint_handler);


    while (1) {
        sleep(1);
        printf("Program running... Press Ctrl+C\n");
       
 
    }

    return 0;
}
