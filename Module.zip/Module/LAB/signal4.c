#include <stdio.h>
#include <signal.h>
#include <unistd.h>

int main() {
    sigset_t set;

    sigemptyset(&set);           // empty set
    sigaddset(&set, SIGINT);     // add Ctrl+C

    sigprocmask(SIG_BLOCK, &set, NULL);  // block

    printf("SIGINT blocked for 5 seconds\n");

    sleep(5);

    sigprocmask(SIG_UNBLOCK, &set, NULL); // unblock

    printf("SIGINT unblocked\n");

    while(1);

    return 0;
}
